<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<div class="row align-items-center justify-content-center">
    <div class="col-6">
        <div class="card text-bg-secondary">
            <div class="card-header text-center">
                Ingresar Propuesta
                <hr>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('propuesta.store')); ?>">
                        <?php echo csrf_field(); ?>
                        

                        <div class="mb-3">
                            <label for="estudiante_rut" class="form-label">Ingrese su rut</label>
                            <input for="estudiante_rut" name="estudiante_rut" id="estudiante_rut"class="form-control">
                        </div>
                        
                        <div class="mb-3">
                            <label for="fecha" class="form-label">Fecha entrega de Propuesta</label>
                            <label for="fecha" class="form-control">hola</label>
                        </div>
                        
                        <div class="mb-3">
                            <label for="propuesta" class="form-label">Ingrese Propuesta</label>
                            <textarea name="propuesta" class="form-control" id="propuesta" rows="3"></textarea>
                          </div>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-outline-light " type="submit">Enviar Propuesta</button>
                            </div>
                        </div>
                        
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</div>





<?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/home/index.blade.php ENDPATH**/ ?>